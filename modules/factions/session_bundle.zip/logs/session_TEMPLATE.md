# Session YYYY-MM-DD — Title

## Save Game (in-world chronicle)
*(700–1200 word war-chronicle recap goes here.)*

## Mechanical Updates
- **Clocks updated:** `/clocks/skyrim_clocks.json`
- **Campaign state updated:** `/state/campaign_state.json`
- **New Aspects created:**
- **Invokes banked:**
- **Consequences taken/cleared:**
- **New Stunts/Extras:**

## Open Threads / Next Scenes
-

## CLOCKS PATCH (copy/paste)
Paste a minimal JSON patch snippet here showing ONLY what changed.
